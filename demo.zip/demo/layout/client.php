<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Rubel Miah">

    <!-- favicon icon -->
    <link rel="shortcut icon" href="public/client/images/icon/image.png">

    <title>KRYSTAL</title>

    <!-- common css -->
    <link rel="stylesheet" href="public/client/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/client/css/font-awesome.min.css">
    <link rel="stylesheet" href="public/client/css/magnific-popup.css">
    <link rel="stylesheet" href="public/client/css/owl.carousel.css">
    <link rel="stylesheet" href="public/client/css/owl.theme.css">
    <link rel="stylesheet" href="public/client/css/slicknav.css">
    <link rel="stylesheet" href="public/client/css/style.css">
    <link rel="stylesheet" href="public/client/css/responsive.css">

    <!-- HTML5 shim and Respond.js IE9 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="public/client/js/html5shiv.js"></script>
    <script src="public/client/js/respond.js"></script>
    <![endif]-->

</head>

<body class="home blog">

    <!--preloader start-->
    <div id="st-preloader">
        <div id="pre-status">
            <div class="preload-placeholder"></div>
        </div>
    </div>
    <!--/preloader end-->

    <!--header start-->
    <div>
        <br>
        <a href="index.php"><center><h1 style="color:#52897b">K R Y S T A L</h1></center></a>
        <br>
        <hr>
    </div>
    <!--/header end-->


    <!--blog start-->
    <div class="container">
        <?php
            if(file_exists($controller))
                include $controller;
        ?>
    </div>
    <!--/blog end-->


    <!--footer start-->
    <footer id="footer">
        <hr>
        <div class="text-center">
            <a class="facebook" href="https://www.facebook.com/kh4l.10cm" target="_blank"><i class="fa fa-facebook"></i><span class="hidden-sm hidden-xs"></span></a> &nbsp;&nbsp;&nbsp;
            <a class="youtube" href="https://www.youtube.com/channel/UCFM1xuiKBmenEGPDRSW7tuA/" target="_blank"><i class="fa fa-youtube"></i> <span class="hidden-sm hidden-xs"></span></a> &nbsp;&nbsp;&nbsp;
            <a class="instagram" href="https://www.instagram.com/kh4l.10cm/" target="_blank"><i class="fa fa-instagram"></i> <span class="hidden-sm hidden-xs"></span></a>
        </div> <!-- /Footer Social -->
        <br>
        <div class="text-center">
<!--
            <span class="type--fine-print"  style="color:#52897b">Made with
                &nbsp;&nbsp;<span style="font-size: 30px; vertical-align: middle;">⌨️</span> &nbsp; and &nbsp;
                <span style="font-size: 30px; vertical-align: middle;">🙌</span>
            </span> <br> <br>
-->
            <span  style="color:#52897b">&copy; 2019 KRYSTAL </span>
        </div>
        <br>
    </footer>
    <!--/footer end-->


    <!-- js files -->
    <script type="text/javascript" src="public/client/js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="public/client/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="public/client/js/jquery.fitvids.js"></script>
    <script type="text/javascript" src="public/client/js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="public/client/js/masonry.min.js"></script>
    <script type="text/javascript" src="public/client/js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="public/client/js/smoothscroll.js"></script>
    <script type="text/javascript" src="public/client/js/jquery.slicknav.js"></script>
    <script type="text/javascript" src="public/client/js/scripts.js"></script>
</body>

</html>
