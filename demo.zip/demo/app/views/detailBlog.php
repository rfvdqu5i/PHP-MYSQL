<div class="row container">
    <div class="col-md-2"></div>
    <div class="col-md-8">
    	<div class="row">
    		<!--post start-->
    		<div class="col-md-12">  
    			<article class="post hentry">
                    <div class="thumbnails">
                        <img src="<?php echo $value["avatar"] ?>" class="post-thumbnail img-responsive" width="100%" />
                    </div>
    				<div class="post-content-area">
    					<header class="entry-header text-center">
                            <div class="post-cat">
                            	<a href="#" rel="category tag">
                            		<?php
                            			$key = $this->Model->fetchOne("select * from menu_catalog where id=".$value["catalog"]);
                            			if(isset($key["name"]))
                            				echo $key["name"];
                            		?>
                            	</a>
                            </div>
                        	<div class="entry-title" style="font-weight: 600px; font-size: 34px;">
                        		<?php echo $value["name"] ?>
                        	</div>  
    					</header>
                        <!--/.entry-header -->
    					<div class="entry-content">
    						<span style="font-style: italic"><?php echo $value["description"] ?></span>
        					<p style="margin-top: 20px;">
<!--                                <b>Nội dung chính: </b> <br>-->
        						<?php echo $value["content"] ?>
        					</p>
                    	</div>
                        <!-- .entry-content -->
                    	<div class="entry-meta text-center">
                    		<div class="share-this hidden-xs">
                    			<?php echo $value["dateTime"] ?>
                    		</div>
                        </div>
                        <!-- .entry-meta -->
    				</div>
    		    </article>
    		</div>
    		<!--/post end-->
    	</div>
    </div>
    <div class="col-md-2"></div>
    <!-- /col -->
    <!--sidebar end-->
</div>